#测试环境URL
url = 'http://testrenshang.cias.cn'

#测试环境DEV
#url = 'http://devrenshang.cias.cn'

#配置发送测试结果邮件开关
sendemail = 1